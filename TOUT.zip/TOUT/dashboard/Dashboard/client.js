// scripts.js

document.addEventListener('DOMContentLoaded', () => {
    const fournisseursLink = document.getElementById('fournisseurs');
    const produitsLink = document.getElementById('produits');
    const clientsLink = document.getElementById('clients');
    const commandesLink = document.getElementById('commandes');
    const contentDiv = document.getElementById('content');
  
    fournisseursLink.addEventListener('click', (e) => {
      e.preventDefault();
      fetch('/api/fournisseurs')
        .then(response => response.json())
        .then(data => {
          // Construire le HTML pour afficher les fournisseurs
          let html = '<h2>Liste des Fournisseurs</h2>';
          html += '<ul>';
          data.forEach(fournisseur => {
            html += `<li>${fournisseur.nom} - ${fournisseur.email}</li>`;
          });
          html += '</ul>';
          contentDiv.innerHTML = html;
        })
        .catch(error => console.error('Erreur lors de la récupération des fournisseurs:', error));
    });
  
    // Ajoutez des événements similaires pour les autres liens (produits, clients, commandes)
  });
  